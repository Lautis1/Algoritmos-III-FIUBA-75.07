package propulsores;

public class PropulsorInteligente implements Propulsable {
	
	
	private int combustible;
	
	
	//estos metodos son iguales al propulsor comun, deben ponerse en otra clase.

	public PropulsorInteligente () {
		this.combustible = 100;
	}
	@Override
	public boolean tieneCombustible(int cantidadDeCombustible) {
		return (this.combustible == cantidadDeCombustible);
	}

	@Override
	public void agregarCombustible(int cantidadDeCombustible) {
		this.combustible = combustible + cantidadDeCombustible;
	}

	
	//este metodo es distinto
	@Override
	public int moverNave() {
		int desplazamiento;
		if (this.combustible > 50) {
			desplazamiento = 10;
		}else {
			desplazamiento = 5;
		}
		this.combustible = (this.combustible - desplazamiento);
		return desplazamiento;
	}

}
