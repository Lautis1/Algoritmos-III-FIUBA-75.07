package propulsores;

public class PropulsorComun implements Propulsable {

	private int combustible;
	
	public PropulsorComun () {
		combustible = 100;
	}
	
	@Override
	public boolean tieneCombustible(int cantidadDeCombustible) {
		return (this.combustible == cantidadDeCombustible);
	}

	@Override
	public void agregarCombustible(int cantidadDeCombustible) {
		this.combustible = (this.combustible + cantidadDeCombustible);
	}

	@Override
	public int moverNave() {
		this.combustible = (this.combustible - 10);
		return 10;
	}

}
