package camuflajes;

public class Activo extends Estado {

	@Override
	public int recibirAtaque() {
		return 0;
	}
	
}
