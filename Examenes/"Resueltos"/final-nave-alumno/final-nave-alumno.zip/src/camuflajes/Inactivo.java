package camuflajes;

public class Inactivo extends Estado {

	@Override
	public int recibirAtaque() {
		return 25;
	}

}
