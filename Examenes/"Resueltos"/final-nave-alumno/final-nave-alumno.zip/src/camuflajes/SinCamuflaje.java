package camuflajes;

public class SinCamuflaje implements Camuflajeable {

	@Override
	public int recibirAtaque() {
		return 25;
	}

	@Override
	public void activar() {

	}

	@Override
	public void desactivar() {
	
	}

}
