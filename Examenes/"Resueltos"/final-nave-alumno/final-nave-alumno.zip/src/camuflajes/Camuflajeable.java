package camuflajes;

public interface Camuflajeable {

	int recibirAtaque();

	void activar();

	void desactivar();

}
