package camuflajes;

public abstract class Estado {

	public abstract int recibirAtaque();
	
}
