package naves;

public interface Movible {

	int moverse();

	boolean tieneCombustible(int cantidadDeCombustible);

	void cargarCombustible(int cantidadDeCombustible);

}
